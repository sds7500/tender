<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ver1";

// Create connection
$conn = new mysqli($servername, $username,$password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


#1$2y$10$R7V5UR8M0K8Rp
#$2y$10$R7V5UR8M0K8Rp


?>

